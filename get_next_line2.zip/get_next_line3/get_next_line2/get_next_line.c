#include "get_next_line.h"

static char *get_line(char **buffer)
{
    char *temp;
    char *ret;
    int i, j;

    i = 0;
    j = 0;
    temp = NULL;
    temp = ft_strdup("");
    if(check_new_line(*buffer))
    {
        temp = malloc(ft_strlen(*buffer) + 1);
        if(!temp)
            return NULL;
        while((*buffer)[i])
        {
            if((*buffer)[i++] == '\n')
            {
                while((*buffer)[i])
                    temp[j++] = (*buffer)[i++];
                (*buffer)[i - j]= '\0';
                break;
            }
        }
        temp[j] = '\0';
    }
    ret = ft_strdup(*buffer);
    free(*buffer);
    *buffer = temp;
    return ret;
}

static char *buff_realloc(char *buffer, int fd)
{
    int byte_read;
    int len;

    len = 0;
    byte_read = 0;
    char *temp = buffer;
    if(!check_new_line(buffer))
    {
        buffer = ft_end(buffer);
        byte_read = read(fd, buffer, BUFFER_SIZE);
        if(byte_read == -1)
            return NULL;
        len += byte_read;
        while(!check_new_line(buffer) && byte_read)
        {
            buffer = ft_end(buffer);
            byte_read = read(fd, buffer, BUFFER_SIZE);
            if(byte_read == -1)
                return NULL;
            len += byte_read;
        }
        buffer[len] = '\0';
    }
    buffer = ft_strdup(temp);
    free(temp);
    return buffer;
}

char *get_next_line(int fd)
{
    static int line;
    static char *buffer;
    char *retbuffer;

    line++;
    if(line == 1)
    {
        buffer = ft_strdup("");
        if(!buffer)
            return NULL;
        buffer = buff_realloc(buffer, fd);
        if(!buffer || !ft_strlen(buffer))
            return NULL;
        return retbuffer = get_line(&buffer);
    }
    buffer = buff_realloc(buffer, fd);
    if(!buffer || !ft_strlen(buffer))
        return NULL;
    retbuffer = get_line(&buffer);
    if(!buffer || !retbuffer)
        return NULL;
    return retbuffer;
}

int main()
{
    int fd = open("a.txt", 2);
    char *buffer = get_next_line(fd);
    while(buffer)
    {
        printf("%s", buffer);
        free(buffer);
        buffer = get_next_line(fd);
    }
    close(fd);
}