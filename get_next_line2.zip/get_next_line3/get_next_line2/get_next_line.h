#ifndef GET_NEXT_LINE_H
#define GET_NEXT_LINE_H

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>

#ifndef BUFFER_SIZE
#define BUFFER_SIZE 10
#endif

char *get_next_line(int fd);
int	check_new_line(char * buffer);
size_t ft_strlen(char *str);
char	*ft_strdup(char *s1);
char *ft_end(char *buffer);

#endif