#include "get_next_line.h"

int main()
{
    char *str = ft_strdup("");
    free(str);
    
}